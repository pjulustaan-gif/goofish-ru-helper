package ru.goofish.translator;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(26),dp(22),dp(22)); root.setBackgroundColor(0xFFFFFFFF);
        TextView title = new TextView(this); title.setText("Goofish RU Helper"); title.setTextSize(24); title.setTextColor(0xFF17231D); title.setPadding(0,0,0,dp(12)); root.addView(title);
        TextView desc = new TextView(this); desc.setText("Тестовый переводчик поверх Goofish\n\n1. Разреши отображение поверх других приложений.\n2. Включи службу доступности Goofish RU Helper.\n3. Открой Goofish и нажми плавающую кнопку «译 / RU».\n\nПомощник читает доступный интерфейс только по нажатию кнопки и отправляет найденный текст в онлайн-переводчик."); desc.setTextSize(16); desc.setTextColor(0xFF34433A); root.addView(desc, new LinearLayout.LayoutParams(-1,0,1));
        Button overlay = new Button(this); overlay.setText("1. Разрешить плавающую кнопку"); overlay.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); else startOverlay(); }); root.addView(overlay, new LinearLayout.LayoutParams(-1,-2));
        Button access = new Button(this); access.setText("2. Открыть настройки доступности"); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(access, new LinearLayout.LayoutParams(-1,-2));
        Button start = new Button(this); start.setText("Запустить плавающую кнопку"); start.setOnClickListener(v -> startOverlay()); root.addView(start, new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
    }
    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); return; }
        startService(new Intent(this, OverlayService.class));
        finish();
    }
}
