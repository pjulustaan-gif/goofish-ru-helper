package ru.goofish.translator;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import org.json.JSONArray;
import java.net.URLEncoder;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class OverlayService extends Service {
    private WindowManager wm; private View bubble; private View panel; private boolean shown=false; private int x,y;
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onCreate(){super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); createBubble();}
    private WindowManager.LayoutParams params(int w,int h,int gravity){return new WindowManager.LayoutParams(w,h,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);}
    private void createBubble(){
        Button b=new Button(this); b.setText("译 / RU"); b.setTextColor(Color.WHITE); b.setTextSize(13); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF16865C)); bubble=b;
        WindowManager.LayoutParams p=params(dp(88),dp(52),Gravity.TOP|Gravity.END); p.gravity=Gravity.TOP|Gravity.END; p.x=dp(8); p.y=dp(220); p.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        b.setOnTouchListener(new View.OnTouchListener(){float sx,sy; int ox,oy; boolean moved; public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;moved=false;return true;} if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)+Math.abs(dy)>dp(8))moved=true;p.x=Math.max(0,ox-(int)dx);p.y=Math.max(0,oy+(int)dy);wm.updateViewLayout(b,p);return true;}if(e.getAction()==MotionEvent.ACTION_UP){if(!moved)togglePanel();return true;}return true;}});
        wm.addView(b,p);
    }
    private void togglePanel(){if(shown){try{wm.removeView(panel);}catch(Exception ignored){} panel=null;shown=false;return;} showPanel("Читаю текст экрана…"); new Thread(()->{String raw=ScreenTextService.readVisibleText(); String translated=translate(raw); runOnUiThreadSafe(()->updatePanel(translated));}).start();}
    private void runOnUiThreadSafe(Runnable r){android.os.Handler h=new android.os.Handler(getMainLooper());h.post(r);}
    private void showPanel(String text){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(10),dp(14),dp(12));box.setBackgroundColor(0xFFF9FCFA);
        TextView head=new TextView(this);head.setText("中文 → Русский");head.setTextSize(18);head.setTypeface(null,Typeface.BOLD);head.setTextColor(0xFF16865C);box.addView(head);
        ScrollView scroll=new ScrollView(this);TextView body=new TextView(this);body.setText(text);body.setTextSize(15);body.setTextColor(0xFF17231D);body.setPadding(0,dp(8),0,dp(8));scroll.addView(body);box.addView(scroll,new LinearLayout.LayoutParams(-1,dp(310)));
        Button close=new Button(this);close.setText("Скрыть перевод");close.setOnClickListener(v->{try{wm.removeView(panel);}catch(Exception ignored){}panel=null;shown=false;});box.addView(close);
        WindowManager.LayoutParams p=params(-1,-2,Gravity.CENTER);p.width=(int)(getResources().getDisplayMetrics().widthPixels*0.92);p.height=dp(430);p.gravity=Gravity.CENTER;p.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        panel=box;wm.addView(panel,p);shown=true;
    }
    private void updatePanel(String text){if(panel==null)return; if(panel instanceof LinearLayout){LinearLayout l=(LinearLayout)panel; if(l.getChildCount()>1 && l.getChildAt(1) instanceof ScrollView){ScrollView s=(ScrollView)l.getChildAt(1);if(s.getChildAt(0) instanceof TextView)((TextView)s.getChildAt(0)).setText(text);}}}
    private String translate(String source){
        if(source==null||source.isEmpty())return "Не удалось получить текст экрана.";
        if(source.startsWith("Сначала включи")||source.startsWith("Не удалось")||source.startsWith("На экране"))return source;
        StringBuilder out=new StringBuilder();String[] lines=source.split("\\n");
        try{for(int i=0;i<lines.length;i++){String line=lines[i].trim();if(line.isEmpty())continue;String translated=translateLine(line);if(out.length()>0)out.append('\n');out.append(translated);if(out.length()>6000)break;}}catch(Exception e){return "Ошибка перевода. Проверь интернет и попробуй ещё раз.\n\n"+source;}
        return out.length()==0?"Нет текста для перевода.":out.toString();
    }
    private String translateLine(String s)throws Exception{
        String url="https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ru&dt=t&q="+URLEncoder.encode(s,"UTF-8");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(9000);c.setRequestProperty("User-Agent","Mozilla/5.0");
        try{BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String z;while((z=r.readLine())!=null)b.append(z);r.close();JSONArray arr=new JSONArray(b.toString()).getJSONArray(0);StringBuilder t=new StringBuilder();for(int i=0;i<arr.length();i++){JSONArray seg=arr.getJSONArray(i);if(seg.length()>0&&!seg.isNull(0))t.append(seg.getString(0));}return t.length()>0?t.toString():s;}finally{c.disconnect();}
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){try{if(bubble!=null)wm.removeView(bubble);}catch(Exception ignored){}try{if(panel!=null)wm.removeView(panel);}catch(Exception ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
