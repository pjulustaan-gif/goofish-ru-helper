package ru.goofish.translator;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.LinkedHashSet;
import java.util.Set;

public class ScreenTextService extends AccessibilityService {
    private static volatile ScreenTextService instance;
    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
    public static String readVisibleText() {
        ScreenTextService s = instance; if (s == null) return "Сначала включи службу доступности Goofish RU Helper в настройках Android.";
        AccessibilityNodeInfo root = s.getRootInActiveWindow(); if (root == null) return "Не удалось прочитать экран. Открой страницу товара и попробуй снова.";
        Set<String> texts = new LinkedHashSet<>(); collect(root, texts, 0); root.recycle();
        StringBuilder out = new StringBuilder(); for (String t : texts) { if (out.length() > 0) out.append('\n'); out.append(t); if (out.length() > 5000) break; }
        return out.length() == 0 ? "На экране не найден текст, доступный для чтения." : out.toString();
    }
    private static void collect(AccessibilityNodeInfo n, Set<String> out, int depth) {
        if (n == null || depth > 35 || out.size() > 250) return;
        CharSequence t = n.getText(); if (t != null) { String v = t.toString().trim(); if (!v.isEmpty() && v.length() < 700) out.add(v); }
        CharSequence d = n.getContentDescription(); if (d != null) { String v=d.toString().trim(); if (!v.isEmpty() && v.length()<300) out.add(v); }
        for (int i=0;i<n.getChildCount();i++) { AccessibilityNodeInfo c=n.getChild(i); if (c!=null) { collect(c,out,depth+1); c.recycle(); } }
    }
}
